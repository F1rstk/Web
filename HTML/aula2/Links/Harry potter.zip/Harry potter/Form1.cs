using System;
using System.Xml.Linq;

namespace Harry_potter
{
    public partial class Form1 : Form
    {
        private Random random;
        public Form1()
        {
            InitializeComponent();
            random = new Random();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SortStudent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ConfirmExit();
        }
        private void ConfirmExit()
        {
            var result = MessageBox.Show("Voc� deseja realmente sair?", "Confirma��o", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                SortStudent();
            }
        }
        private void SortStudent()
        {
            string studentName = textBox1.Text.Trim();
            if (string.IsNullOrEmpty(studentName))
            {
                MessageBox.Show("Por favor, insira o nome do aluno.");
                return;
            }

            string house = GetRandomHouse();
            MessageBox.Show($"{studentName} ir� para a casa {house}.");

            AddStudentToHouse(studentName, house);
            textBox1.Clear();
            textBox1.Focus();
        }
        private string GetRandomHouse()
        {
            int houseIndex = random.Next(0, 4);
            switch (houseIndex)
            {
                case 0: return "Grifin�ria";
                case 1: return "Lufa-Lufa";
                case 2: return "Corvinal";
                case 3: return "Sonserina";
                default: return "Desconhecida";
            }
        }
        private void AddStudentToHouse(string studentName, string house)
        {
            switch (house)
            {
                case "Grifin�ria":
                    listBox1.Items.Add(studentName);
                    break;
                case "Lufa-Lufa":
                    listBox2.Items.Add(studentName);
                    break;
                case "Corvinal":
                    listBox3.Items.Add(studentName);
                    break;
                case "Sonserina":
                    listBox4.Items.Add(studentName);
                    break;
            }

        }

    }
}

